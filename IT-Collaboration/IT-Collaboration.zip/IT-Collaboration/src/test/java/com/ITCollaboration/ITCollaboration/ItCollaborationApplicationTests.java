package com.ITCollaboration.ITCollaboration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItCollaborationApplicationTests {

	@Test
	void contextLoads() {
	}

}
