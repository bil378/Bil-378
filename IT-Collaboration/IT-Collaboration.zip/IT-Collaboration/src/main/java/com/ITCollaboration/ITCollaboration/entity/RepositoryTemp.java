package com.ITCollaboration.ITCollaboration.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryTemp extends JpaRepository<TempEntity, Integer> {

}
